#!/bin/bash


#hg bookmark -f default
#hg push github
#hg bookmarks -d default

hg bookmark -r default master
hg push github